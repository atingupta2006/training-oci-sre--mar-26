# BharatMart OCI Deployment - Terraform Configuration (Single All-in-One VM)

This directory contains Terraform configuration files for deploying BharatMart infrastructure on Oracle Cloud Infrastructure (OCI) using a **single all-in-one VM** that hosts both frontend and backend services.

## Overview

This Terraform configuration creates a minimal but complete infrastructure setup for BharatMart:

- **VCN** (Virtual Cloud Network) with public subnet only
- **Internet Gateway** for public subnet connectivity
- **Security Lists** with appropriate rules for direct access to the VM
- **Single Compute Instance** (all-in-one) hosting both frontend and backend API

**Note:** This is a simplified deployment option ideal for development, testing, or training purposes. For production, consider using `option-2` (instance pools with auto-scaling).

## Prerequisites

> **⚠️ INSTRUCTOR PROVIDED FILES**  
> Sensitive files are excluded from this git repository. To proceed with this lab, your instructor will securely provide you with:  
> 1. A pre-filled `terraform.tfvars` file containing the required OCIDs, passwords, and API keys.  
> 2. `oci_api_key.pem` (if testing via local CLI).  
> 3. SSH keypairs for Compute instance access.  
> **Please ask your instructor for these files before starting.**

1. **OCI Account** with appropriate permissions
2. **OCI Compartment** OCID where resources will be created
3. **Terraform** version >= 1.5.0 (for local testing, or use OCI Resource Manager)
4. **OCI Image** OCID (Oracle Linux or Ubuntu)
5. **SSH Public Key** for Compute instance access

## File Structure

```
deployment/terraform/option-1/
├── versions.tf          # Terraform and provider version requirements
├── variables.tf         # Input variable definitions
├── main.tf              # Main infrastructure resources
├── outputs.tf           # Output values (resource IDs, IPs, etc.)
├── terraform.tfvars.example  # Example variables file
└── README.md            # This file
```

## Quick Start

### Using OCI Resource Manager (Recommended for Training)

1. **Create a ZIP file** of the Terraform configuration:
   ```bash
   cd deployment/terraform/option-1
   zip -r bharatmart-option1.zip *.tf
   ```

2. **Upload to Resource Manager**:
   - Go to OCI Console → Menu (☰) → Developer Services → Resource Manager → Stacks
   - Click "Create Stack"
   - Choose "My Local Machine"
   - Upload `bharatmart-option1.zip`
   - Fill in variables (compartment_id, image_id, ssh_public_key, etc.)
   - Review and create stack

3. **Run Plan**:
   - Open your stack
   - Click "Terraform Actions → Plan"
   - Review the plan output

4. **Apply**:
   - Click "Terraform Actions → Apply"
   - Wait for resources to be created

### Using Terraform CLI (Optional)

1. **Initialize Terraform**:
   ```bash
   cd deployment/terraform/option-1
   terraform init
   ```

2. **Configure variables**:
   ```bash
   cp /path/to/downloaded/terraform.tfvars .
   # Use the file provided securely by your instructor
   ```

3. **Plan**:
   ```bash
   terraform plan
   ```

4. **Apply**:
   ```bash
   terraform apply
   ```

## Required Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `compartment_id` | OCI Compartment OCID | `ocid1.compartment.oc1..aaaaaaa...` |
| `image_id` | OCI Image OCID | `ocid1.image.oc1.iad.aaaaaaaa...` |
| `ssh_public_key` | SSH public key content | `ssh-rsa AAAAB3...` |

## Key Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `region` | `ap-mumbai-1` | OCI region |
| `project_name` | `bharatmart` | Project name for resource naming |
| `environment` | `dev` | Environment (dev/staging/prod) |
| `compute_instance_shape` | `VM.Standard.A1.Flex` | Compute instance shape |
| `compute_instance_ocpus` | `2` | Number of OCPUs for the VM |
| `compute_instance_memory_in_gb` | `12` | Memory in GB for the VM |
| `public_subnet_cidr` | `10.0.1.0/24` | CIDR block for public subnet |

## What Gets Created

### Networking
- **VCN** with CIDR block (default: 10.0.0.0/16)
- **Public Subnet** (default: 10.0.1.0/24) - for all-in-one VM
- **Internet Gateway** - for public subnet

### Security
- **Public Security List** - allows:
  - HTTP (80) from internet
  - HTTPS (443) from internet
  - API (3000) from internet
  - SSH (22) from internet (dev only)

### Compute
- **Single Compute Instance** (all-in-one) - hosts both frontend and backend
  - Deployed in public subnet with public IP
  - Basic Node.js installation via user_data
  - SSH access configured
  - Direct access to application on port 3000

## Outputs

After successful deployment, the following outputs are available:

- `vcn_id` - VCN OCID
- `public_subnet_id` - Public subnet OCID
- `compute_instance_id` - All-in-one VM OCID
- `compute_instance_public_ip` - Public IP of the VM
- `compute_instance_private_ip` - Private IP of the VM
- `application_url` - Full URL to access application (`http://<public-ip>:3000`)
- `ssh_command` - SSH command to connect to the instance

## Post-Deployment Steps

After Terraform creates the infrastructure:

1. **Initialize Supabase Database**:
   - Open your Supabase project's SQL Editor and create the required execution function:
     ```sql
     CREATE OR REPLACE FUNCTION public.exec_sql(sql text)
     RETURNS void
     LANGUAGE plpgsql
     SECURITY DEFINER
     AS $$
     BEGIN
       EXECUTE sql;
     END;
     $$;
     ```
   - From your local machine (inside the cloned repository), run the database init script to create tables and seed products:
     ```bash
     npm install
     npm run db:init
     ```

2. **SSH to the Compute instance**:
   ```bash
   ssh -i ~/.ssh/your_key opc@<public_ip>
   ```

3. **Deploy BharatMart application**:
   - The repository has already been cloned and dependencies installed by Terraform!
   - Run the exact copy-paste commands provided in `commands.sh` (located in the `option-1` folder) to instantly configure your IP address, disable the firewall, and start the frontend and backend servers.

4. **Verify Application**:
   ```bash
   curl http://<public_ip>:3000/api/health
   ```

5. **Access Application**:
   - Open browser to `http://<public_ip>:3000`
   - API available at `http://<public_ip>:3000/api/*`

## Architecture Differences from Other Options

### Option-1 (This Option)
- ✅ Single VM for everything
- ✅ Simple setup
- ✅ Lower cost
- ❌ No high availability
- ❌ No load balancing
- ❌ Single point of failure

### Option-2 (Instance Pools with Auto-Scaling)
- Instance pools for scalability
- Auto-scaling based on metrics
- Best for production with variable load

## Version Information

- **Terraform**: >= 1.5.0
- **OCI Provider**: ~> 5.0
