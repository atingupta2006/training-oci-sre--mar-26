########################################
# REQUIRED VARIABLES
########################################

compartment_id = "ocid1.compartment.oc1..aaaaaaaavzlulwgc4twmrqqfsb5jack4i6cgq3t6yzc2rwhslppf53rrbb5q"
image_id       = "ocid1.image.oc1.ap-mumbai-1.aaaaaaaalz54iem5lapeuvv6p5hkqvqc2of7g5ajioqo7r6ndzw67z5v2iqa"
ssh_public_key = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDXtqPzYXOZiVaR8SIFM3Yftb1PVvq0JmWukV3gTLyTB9mYlC++DfzHel5HEyMArrBMCzDjX2CKJ7DegFKnbLeVh9aoePP/z7yBNzTknNS7NRe+CFdT12YRFv5YXsgG8tJ/bq/NjWWuuJrF/HoOt/gwl+96mNEyIir4pmFC/2/6M5Rue3BdquN9Y2hq/yD3gyRPUqs/jlGmdmTt2PhVDGs7DZJ7SnYMWv1IsrLc0T982oqcnV/+M5x5uSwZCDngZdmZEs/y6EBKLy04JAPVqVG8SMm0taAlJwTCiOPRYsmkHzxRdSij+81i/lwLhlERGza2ppD8RsKAFGEt836bVypioTB8LAW0Cm9T0KL/+B3l0ejcmgkemBGawZNOMsM15eMi9TicvCv1XqoqztsjgDBLGDxk2/unHf9bftlR9uF23VDYjyB2KDLw3P2TZm8aHCnvSUkt3u6ZSYQgR/pzF9ScdKFzxomtVh67dFIzsiW29kfbsb2ikbjE6kRhABJsoKE= PC@DESKTOP-BULK9T0"


########################################
# GENERAL SETTINGS
########################################

region              = "ap-mumbai-1"
availability_domain = "AD-1"
project_name        = "bharatmart"
environment         = "dev"

########################################
# NETWORK CONFIG
########################################

vcn_cidr           = "10.0.0.0/16"
public_subnet_cidr = "10.0.1.0/24"

########################################
# COMPUTE INSTANCE SETTINGS (All-in-One VM)
########################################

compute_instance_shape        = "VM.Standard.E5.Flex"

# Optional OCPU/memory override for FLEX shapes
compute_instance_ocpus        = 2
compute_instance_memory_in_gb = 12

########################################
# TAGS
########################################

tags = {
  "Project"     = "BharatMart"
  "ManagedBy"   = "Terraform"
  "Environment" = "dev"
  "Team"        = "SRE"
}
